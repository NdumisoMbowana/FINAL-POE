﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace POE
{
    public partial class MainWindow : Window
    {
        public class Recipe
        {
            public string Name { get; set; }
            public List<Ingredient> Ingredients { get; set; }
            public List<Step> Steps { get; set; }

            public Recipe(string name)
            {
                Name = name;
                Ingredients = new List<Ingredient>();
                Steps = new List<Step>();
            }

            public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
            {
                Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
            }

            public void AddStep(string description)
            {
                Steps.Add(new Step { Description = description });
            }

            public void DisplayRecipe(TextBox output)
            {
                output.AppendText($"Recipe: {Name}\n");
                output.AppendText("Ingredients:\n");
                foreach (var ingredient in Ingredients)
                {
                    output.AppendText($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}\n");
                }
                output.AppendText("Steps:\n");
                for (int i = 0; i < Steps.Count; i++)
                {
                    output.AppendText($"{i + 1}. {Steps[i].Description}\n");
                }
            }

            public int TotalCalories()
            {
                return Ingredients.Sum(ingredient => ingredient.Calories);
            }
        }

        public delegate void RecipeCaloriesNotification(string recipeName, int totalCalories);

        public class Ingredient
        {
            public string Name { get; set; }
            public double Quantity { get; set; }
            public string Unit { get; set; }
            public int Calories { get; set; }
            public string FoodGroup { get; set; }
        }

        public class Step
        {
            public string Description { get; set; }
        }

        private List<Recipe> recipes = new List<Recipe>();
        private event RecipeCaloriesNotification NotifyCaloriesExceed;

        public MainWindow()
        {
            InitializeComponent();
            NotifyCaloriesExceed += NotifyCaloriesExceedHandler;
        }

        

        private void NotifyCaloriesExceedHandler(string recipeName, int totalCalories)
        {
            MessageBox.Show($"Warning: The total calories of recipe '{recipeName}' exceed 300. Total calories: {totalCalories}", "Calorie Alert", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        public static class Prompt
        {
            public static string ShowDialog(string text, string caption)
            {
                Window prompt = new Window()
                {
                    Width = 300,
                    Height = 200,
                    Title = caption,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen
                };

                StackPanel stackPanel = new StackPanel();
                TextBlock textBlock = new TextBlock() { Text = text, Margin = new Thickness(10) };
                TextBox textBox = new TextBox() { Margin = new Thickness(10) };
                Button okButton = new Button() { Content = "OK", Width = 50, Margin = new Thickness(10) };
                okButton.Click += (sender, e) => { prompt.DialogResult = true; };

                stackPanel.Children.Add(textBlock);
                stackPanel.Children.Add(textBox);
                stackPanel.Children.Add(okButton);
                prompt.Content = stackPanel;
                prompt.ShowDialog();

                return textBox.Text;
            }
        }

        private void BtnNewRecipe_Click(object sender, RoutedEventArgs e)
        {
            string name = Prompt.ShowDialog("Enter the name of the recipe:", "New Recipe");
            Recipe recipe = new Recipe(name);

            int numIngredients = int.Parse(Prompt.ShowDialog("Enter the number of ingredients:", "New Recipe"));
            for (int i = 0; i < numIngredients; i++)
            {
                string ingredientName = Prompt.ShowDialog($"Enter the name of ingredient {i + 1}:", "New Ingredient");
                double quantity = double.Parse(Prompt.ShowDialog($"Enter the quantity of ingredient {i + 1}:", "New Ingredient"));
                string unit = Prompt.ShowDialog($"Enter the unit of measurement for ingredient {i + 1}:", "New Ingredient");
                int calories = int.Parse(Prompt.ShowDialog($"Enter the calories of ingredient {i + 1}:", "New Ingredient"));
                string foodGroup = Prompt.ShowDialog($"Enter the food group of ingredient {i + 1}:", "New Ingredient");

                recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
            }

            int numSteps = int.Parse(Prompt.ShowDialog("Enter the number of steps:", "New Recipe"));
            for (int i = 0; i < numSteps; i++)
            {
                string description = Prompt.ShowDialog($"Enter the description of step {i + 1}:", "New Step");
                recipe.AddStep(description);
            }

            recipes.Add(recipe);

            int totalCalories = recipe.TotalCalories();
            if (totalCalories > 300)
            {
                NotifyCaloriesExceed(name, totalCalories);
            }
        }

        private void BtnDisplayAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            TxtOutput.Clear();
            if (recipes.Count == 0)
            {
                TxtOutput.AppendText("No recipes entered yet.\n");
                return;
            }

            TxtOutput.AppendText("List of Recipes:\n");
            foreach (var recipe in recipes.OrderBy(r => r.Name))
            {
                TxtOutput.AppendText($"{recipe.Name}\n");
            }
        }

        private void BtnDisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            TxtOutput.Clear();
            if (recipes.Count == 0)
            {
                TxtOutput.AppendText("No recipes entered yet.\n");
                return;
            }

            string recipeName = Prompt.ShowDialog("Enter the name of the recipe to display:", "Display Recipe");
            var recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            if (recipe != null)
            {
                recipe.DisplayRecipe(TxtOutput);
            }
            else
            {
                TxtOutput.AppendText("Recipe not found.\n");
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {

            Application.Current.Shutdown();
        }
    }
}

